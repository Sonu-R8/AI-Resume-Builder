// AI Resume Builder - Premium Web Application with ATS Scoring & Templates

class AIResumeBuilder {
  constructor() {
    this.currentRoute = '/';
    this.selectedTemplate = 'classic';
    this.selectedColor = 'teal';
    this.atsScore = 0;
    this.atsSuggestions = [];
    this.submissionData = {
      lovable: '',
      github: '',
      deployed: '',
      shipped: false
    };
    this.resumeData = {
      personal: {
        name: '',
        email: '',
        phone: '',
        location: ''
      },
      summary: '',
      education: [],
      experience: [],
      projects: [],
      skills: {
        technical: [],
        soft: [],
        tools: []
      },
      links: {
        github: '',
        linkedin: ''
      }
    };
    this.atsScore = 0;
    this.atsSuggestions = [];
    this.improvements = [];
    this.autosaveTimer = null;
    this.collapsedProjects = new Set();
    this.init();
  }

  init() {
    this.loadDataFromStorage();
    this.setupRouting();
    this.render();
    this.attachEventListeners();
    this.calculateATSScore();
    this.calculateImprovements();
  }

  // ATS Scoring Methods
  calculateATSScore() {
    let score = 0;
    const suggestions = [];

    // +10 if name provided
    if (this.resumeData.personal.name.trim()) {
      score += 10;
    } else {
      suggestions.push('Add your full name (+10 points)');
    }

    // +10 if email provided
    if (this.resumeData.personal.email.trim()) {
      score += 10;
    } else {
      suggestions.push('Add your email address (+10 points)');
    }

    // +10 if summary > 50 chars
    if (this.resumeData.summary.length > 50) {
      score += 10;
    } else {
      suggestions.push('Write a longer summary (+10 points)');
    }

    // +15 if at least 1 experience entry with bullets
    if (this.resumeData.experience.length > 0) {
      score += 15;
    } else {
      suggestions.push('Add work experience (+15 points)');
    }

    // +10 if at least 1 education entry
    if (this.resumeData.education.length > 0) {
      score += 10;
    } else {
      suggestions.push('Add your education (+10 points)');
    }

    // +10 if at least 5 skills total
    const allSkills = this.resumeData.skills.technical.concat(this.resumeData.skills.soft, this.resumeData.skills.tools);
    if (allSkills.length >= 5) {
      score += 10;
    } else {
      suggestions.push(`Add more skills (currently ${allSkills.length}, target 5+)`);
    }

    // +10 if at least 1 project
    if (this.resumeData.projects.length > 0) {
      score += 10;
    } else {
      suggestions.push('Add at least one project (+10 points)');
    }

    // +5 if phone provided
    if (this.resumeData.personal.phone.trim()) {
      score += 5;
    } else {
      suggestions.push('Add your phone number (+5 points)');
    }

    // +5 if LinkedIn provided
    if (this.resumeData.links.linkedin.trim()) {
      score += 5;
    } else {
      suggestions.push('Add your LinkedIn profile (+5 points)');
    }

    // +5 if GitHub provided
    if (this.resumeData.links.github.trim()) {
      score += 5;
    } else {
      suggestions.push('Add your GitHub profile (+5 points)');
    }

    // +10 if summary contains action verbs
    const actionVerbs = ['built', 'led', 'designed', 'improved', 'created', 'developed', 'implemented', 'optimized', 'managed', 'launched', 'reduced', 'increased', 'generated', 'achieved', 'completed'];
    const summaryLower = this.resumeData.summary.toLowerCase();
    if (actionVerbs.some(verb => summaryLower.includes(verb))) {
      score += 10;
    } else {
      suggestions.push('Use action verbs in your summary (+10 points)');
    }

    // Cap at 100
    this.atsScore = Math.min(score, 100);
    this.atsSuggestions = suggestions;
    this.updateATSDisplay();
  }

  setupRouting() {
    window.addEventListener('hashchange', () => {
      this.currentRoute = window.location.hash || '/';
      this.render();
    });
  }

  getRoute() {
    return window.location.hash || '/';
  }

  // Data Management Methods
  loadDataFromStorage() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.resumeData = parsed.resumeData || this.resumeData;
        this.selectedTemplate = parsed.selectedTemplate || 'classic';
        this.selectedColor = parsed.selectedColor || 'teal';
        this.submissionData = parsed.submissionData || this.submissionData;
        
        // Migrate old skills format to new format
        if (typeof this.resumeData.skills === 'string') {
          const oldSkills = this.resumeData.skills.split(',').map(skill => skill.trim()).filter(skill => skill.length > 0);
          this.resumeData.skills = {
            technical: oldSkills.filter(skill => this.isTechnicalSkill(skill)),
            soft: oldSkills.filter(skill => this.isSoftSkill(skill)),
            tools: oldSkills.filter(skill => this.isToolSkill(skill))
          };
        }
      }
    } catch (error) {
      console.warn('Failed to load data from localStorage:', error);
    }
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  saveSubmissionData() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate,
        selectedColor: this.selectedColor,
        submissionData: this.submissionData
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save submission data:', error);
    }
  }

  loadSubmissionData() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.submissionData = parsed.submissionData || this.submissionData;
      }
      return this.submissionData;
    } catch (error) {
      console.warn('Failed to load submission data:', error);
      return this.submissionData;
    }
  }

  updateArtifact(field, value) {
    this.submissionData[field] = value;
    this.saveSubmissionData();
    this.updateProofDisplay();
  }

  updateProofDisplay() {
    const proofContainer = document.querySelector('.proof-container');
    if (proofContainer) {
      proofContainer.innerHTML = this.getProofPage();
    }
  }

  isShipped() {
    // Check if all requirements are met for shipping
    return this.submissionData.shipped || (
      this.submissionData.lovable && 
      this.submissionData.github && 
      this.submissionData.deployed
    );
  }

  markAsShipped() {
    this.submissionData.shipped = true;
    this.saveSubmissionData();
    this.updateProofDisplay();
    this.showNotification('🚀 Project 3 Shipped Successfully.');
  }

  copyFinalSubmission() {
    const submission = this.loadSubmissionData();
    const submissionText = `
------------------------------------------
AI Resume Builder — Final Submission

Lovable Project: ${submission.lovable || 'Not provided'}
GitHub Repository: ${submission.github || 'Not provided'}
Live Deployment: ${submission.deployed || 'Not provided'}

Core Capabilities:
- Structured resume builder
- Deterministic ATS scoring
- Template switching
- PDF export with clean formatting
- Persistence + validation checklist
------------------------------------------
    `;
    
    navigator.clipboard.writeText(submissionText).then(() => {
      this.showNotification('Final submission copied to clipboard!');
    }).catch(err => {
      console.error('Failed to copy submission:', err);
      this.showNotification('Failed to copy submission. Please try again.');
    });
  }

  // Template Methods
  switchTemplate(template) {
    this.selectedTemplate = template;
    this.autosave();
    this.updateTemplateDisplay();
    this.updatePreview();
  }

  switchColor(color) {
    this.selectedColor = color;
    this.autosave();
    this.updateTemplateDisplay();
    this.updatePreview();
  }

  // Template Definitions
  getTemplateDefinitions() {
    return {
      classic: {
        name: 'Classic',
        description: 'Traditional single-column layout with serif headings and horizontal rules',
        layout: 'single-column'
        typography: {
          headerFont: 'Georgia, serif',
          bodyFont: '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", sans-serif',
          scale: '1.0'
        },
        spacing: {
          sectionGap: '24px',
          lineHeight: '1.6'
        },
        colors: {
          primary: '#000000',
          accent: '#8B0000',
          text: '#111111',
          background: '#FFFFFF',
          border: '#E5E5E5E5'
        }
      },
      modern: {
        name: 'Modern',
        description: 'Two-column layout with colored sidebar and clean typography',
        layout: 'two-column',
        typography: {
          headerFont: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
          scale: '1.0'
        },
        spacing: {
          sectionGap: '20px',
          lineHeight: '1.5'
        },
        colors: {
          primary: '#2563EB',
          accent: '#4CAF50',
          text: '#333333',
          background: '#FFFFFF',
          border: '#E5E5E5E5'
        }
      },
      minimal: {
        name: 'Minimal',
        section: 'Clean single-column with generous whitespace',
        layout: 'single-column',
        typography: {
          headerFont: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
          scale: '1.0'
        },
        spacing: {
          sectionGap: '32px',
          lineHeight: '1.7'
        },
        colors: {
          primary: '#2C3E50',
          accent: '#66BB6A',
          text: '#1A1A1A1',
          background: '#FFFFFF',
          border: '#E5E5E5E5'
        }
      }
    };
  }

  getColorDefinitions() {
    return {
      teal: {
        name: 'Teal',
        primary: '#00695C',
        accent: '#38B000',
        text: '#FFFFFF',
        background: '#F0F4F4',
        border: '#B2DFDB'
      },
      blue: {
        name: 'Blue',
        primary: '#1976D2',
        accent: '#2196F3',
        text: '#FFFFFF',
        background: '#F0F7FF',
        border: '#BB6F'
      },
      burgundy: {
        name: 'Burgundy',
        primary: '#800020',
        accent: '#31192F',
        text: '#FFFFFF',
        background: '#FDF5E6',
        border: '#58111'
      },
      forest: {
        name: 'Forest',
        primary: '#228B22',
        accent: '#20A24A',
        text: '#FFFFFF',
        background: '#F1F1F1',
        border: '#434343'
      },
      charcoal: {
        name: 'Charcoal',
        primary: '#1E1E1E1',
        accent: '#434343',
        text: '#FFFFFF',
        background: '#1E1E1E1'
        border: '#434343'
      },
      navy: {
        name: 'Navy',
        primary: '#1E3A8F',
        accent: '#764BA2',
        text: '#FFFFFF',
        background: '#F0F7FF',
        border: '#31192F'
      }
    };
  }

  loadDataFromStorage() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.resumeData = parsed.resumeData || this.resumeData;
        this.selectedTemplate = parsed.selectedTemplate || 'classic';
        this.selectedColor = parsed.selectedColor || 'teal';
        
        // Migrate old skills format to new format
        if (typeof this.resumeData.skills === 'string') {
          const oldSkills = this.resumeData.skills.split(',').map(skill => skill.trim()).filter(skill => skill.length > 0);
          this.resumeData.skills = {
            technical: oldSkills.filter(skill => this.isTechnicalSkill(skill)),
            soft: oldSkills.filter(skill => this.isSoftSkill(skill)),
            tools: oldSkills.filter(skill => this.isToolSkill(skill))
          };
        }
      }
    } catch (error) {
      console.warn('Failed to load data from localStorage:', error);
    }
  }

  isTechnicalSkill(skill) {
    const technicalSkills = ['JavaScript', 'Python', 'React', 'Node.js', 'TypeScript', 'PostgreSQL', 'MongoDB', 'GraphQL', 'Docker', 'Kubernetes', 'AWS', 'Git', 'Express', 'Redis'];
    return technicalSkills.some(tech => skill.toLowerCase().includes(tech.toLowerCase()));
  }

  isSoftSkill(skill) {
    const softSkills = ['Team Leadership', 'Problem Solving', 'Communication', 'Project Management', 'Mentoring', 'Collaboration', 'Critical Thinking'];
    return softSkills.some(soft => skill.toLowerCase().includes(soft.toLowerCase()));
  }

  isToolSkill(skill) {
    const toolSkills = ['Git', 'Docker', 'AWS', 'Kubernetes', 'Jira', 'VS Code', 'Figma', 'Chrome DevTools'];
    return toolSkills.some(tool => skill.toLowerCase().includes(tool.toLowerCase()));
  }

  // Render Methods
  render() {
    const appContainer = document.getElementById('app');
    if (!appContainer) return;

    appContainer.innerHTML = this.getLayoutHTML();
  }

  getLayoutHTML() {
    const route = this.getRoute();
    let content = '';

    switch (route) {
      case '/':
      case '#/':
        content = this.getHomePage();
        break;
      case '#/builder':
        content = this.getBuilderPage();
        break;
      case '#/preview':
        content = this.getPreviewPage();
        break;
      case '#/proof':
        content = this.getProofPage();
        break;
      default:
        content = this.getHomePage();
        break;
    }

    return content;
  }

  getHomePage() {
    return `
      ${this.getNavigation()}
      <main class="main-content">
        <div class="home-container">
          <h1 class="home-headline">Build a Resume That Gets Read.</h1>
          <p class="home-subtitle">Create a professional, ATS-optimized resume that showcases your skills and experience.</p>
          <a href="#/builder" class="cta-button">Start Building</a>
        </div>
      </main>
    `;
  }

  getBuilderPage() {
    return `
      ${this.getNavigation()}
      <main class="main-content">
        <div class="builder-container">
          <div class="builder-form">
            <div class="card">
              <h2 class="card-title">Resume Builder</h2>
              
              ${this.getTemplatePicker()}
              ${this.getATSScoreDisplay()}
              ${this.getImprovementPanel()}
              
              ${this.getPersonalInfoSection()}
              ${this.getSummarySection()}
              ${this.getEducationSection()}
              ${this.getExperienceSection()}
              ${this.getProjectsSection()}
              ${this.getSkillsSection()}
              ${this.getLinksSection()}
              
              <div class="btn-group">
                <button class="btn btn-secondary" onclick="aiResumeBuilder.loadSampleData()">Load Sample Data</button>
              </div>
            </div>
          </div>
          
          <div class="builder-preview">
            <div class="preview-panel template-${this.selectedTemplate} template-${this.selectedColor}">
              ${this.getLivePreview()}
            </div>
          </div>
        </div>
      </main>
    `;
  }

  getTemplatePicker() {
    const templates = this.getTemplateDefinitions();
    const colors = this.getColorDefinitions();
    
    return `
      <div class="template-picker">
        <div class="template-picker-header">
          <div class="template-picker-title">Choose Template</div>
          <button class="template-picker-close" onclick="aiResumeBuilder.closeTemplatePicker()">×</button>
        </div>
        
        <div class="template-thumbnails">
          ${Object.entries(templates).map(([key, template]) => `
            <div class="template-thumbnail ${this.selectedTemplate === key ? 'active' : ''}" onclick="aiResumeBuilder.switchTemplate('${key}')" title="${template.name}">
              <div class="template-thumbnail-content">
                <div class="template-thumbnail-name">${template.name}</div>
                <div class="template-thumbnail-preview">${template.name}</div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
      
      <div class="template-themes">
        <div class="template-picker-title">Choose Color Theme</div>
        ${Object.entries(colors).map(([key, color]) => `
          <div class="theme-option ${this.selectedColor === key ? 'active' : ''}" onclick="aiResumeBuilder.switchColor('${key}')" title="${color.name}">
            <div class="theme-color-preview ${this.selectedColor === key ? 'selected' : ''}" style="background-color: ${color.primary}"></div>
          </div>
        `).join('')}
      </div>
    `;
  }

  closeTemplatePicker() {
    const picker = document.querySelector('.template-picker');
    if (picker) {
      picker.style.display = 'none';
    }
  }

  switchTemplate(template) {
    this.selectedTemplate = template;
    this.autosave();
    this.updateTemplateDisplay();
    this.updatePreview();
  }

  switchColor(color) {
    this.selectedColor = color;
    this.autosave();
    this.updateTemplateDisplay();
    this.updatePreview();
  }

  updateTemplateDisplay() {
    const picker = document.querySelector('.template-picker');
    if (picker) {
      picker.style.display = 'flex';
    }
    
    // Update template thumbnails
    const thumbnails = document.querySelectorAll('.template-thumbnail');
    thumbnails.forEach(thumb => {
      thumb.classList.toggle('active', thumb.dataset.template === this.selectedTemplate);
    });
    
    // Update theme options
    const themeOptions = document.querySelectorAll('.theme-option');
    themeOptions.forEach(option => {
      option.classList.toggle('active', option.dataset.color === this.selectedColor);
    });
    
    // Update preview panel
    const previewPanel = document.querySelector('.preview-panel');
    if (previewPanel) {
      previewPanel.className = `preview-panel template-${this.selectedTemplate} template-${this.selectedColor}`;
    }
  }

  updatePreview() {
    const previewPanel = document.querySelector('.preview-panel');
    if (previewPanel) {
      previewPanel.innerHTML = this.getLivePreview();
    }
  }

  // Existing methods (keep unchanged)
  getPersonalInfoSection() { /* ... */ }
  getSummarySection() { /* ... */ }
  getEducationSection() { /* ... */ }
  getExperienceSection() { /* ... */ }
  getProjectsSection() { /* ... */ }
  getSkillsSection() { /* ... */ }
  getLinksSection() { /* ... */ }
  getATSScoreMeter() { /* ... */ }
  getImprovementPanel() { /* ... */ }
  getLivePreview() { /* ... */ }
  getNavigation() { /* ... */ }
  attachEventListeners() { /* ... */ }
  calculateATSScore() { /* ... */ }
  calculateImprovements() { /* ... */ }
  updateATSDisplay() { /* ... */ }
  updateImprovementDisplay() { /* ... */ }
  showNotification(message) { /* ... */ }
  loadSampleData() { /* ... */ }
  updatePreview() { /* ... */ }
  autosave() { /* ... */ }
}

  // Export Methods
  printResume() {
    window.print();
  }

  getProofPage() {
    return `
      ${this.getNavigation()}
      <main class="main-content">
        <div class="proof-container">
          <h1 class="proof-headline">Project 3 — Final Submission</h1>
          
          ${this.getStepCompletionOverview()}
          ${this.getArtifactCollectionSection()}
          ${this.getFinalSubmissionSection()}
          ${this.getShippedStatusSection()}
        </div>
      </main>
    `;
  }

  getStepCompletionOverview() {
    const steps = [
      { id: 1, title: 'Project Setup', completed: this.isStepCompleted(1) },
      { id: 2, title: 'Resume Content', completed: this.isStepCompleted(2) },
      { id: 3, title: 'ATS Optimization', completed: this.isStepCompleted(3) },
      { id: 4, title: 'Template Selection', completed: this.isStepCompleted(4) },
      { id: 5, title: 'Export Ready', completed: this.isStepCompleted(5) },
      { id: 6, title: 'Final Review', completed: this.isStepCompleted(6) },
      { id: 7, title: 'Submission', completed: this.isStepCompleted(7) },
      { id: 8, title: 'Shipped', completed: this.isStepCompleted(8) }
    ];

    return `
      <div class="proof-section">
        <h2 class="proof-section-title">Step Completion Overview</h2>
        <div class="step-progress">
          ${steps.map(step => `
            <div class="step-item ${step.completed ? 'completed' : 'pending'}">
              <div class="step-number">${step.id}</div>
              <div class="step-content">
                <div class="step-title">${step.title}</div>
                <div class="step-status">${step.completed ? '✅ Completed' : '⏳ In Progress'}</div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  isStepCompleted(stepId) {
    // This would be connected to actual completion logic
    // For now, return false for demo
    return false;
  }

  getArtifactCollectionSection() {
    const submission = this.loadSubmissionData();
    
    return `
      <div class="proof-section">
        <h2 class="proof-section-title">A) Artifact Collection</h2>
        <div class="artifact-form">
          <div class="form-group">
            <label class="form-label">Lovable Project Link</label>
            <input type="url" class="input" id="lovable-link" placeholder="https://lovable.dev/projects/your-project" value="${submission.lovable || ''}" onchange="aiResumeBuilder.updateArtifact('lovable', this.value)">
            <div class="form-help">Required to mark as shipped</div>
          </div>
          
          <div class="form-group">
            <label class="form-label">GitHub Repository Link</label>
            <input type="url" class="input" id="github-link" placeholder="https://github.com/username/repository" value="${submission.github || ''}" onchange="aiResumeBuilder.updateArtifact('github', this.value)">
            <div class="form-help">Required to mark as shipped</div>
          </div>
          
          <div class="form-group">
            <label class="form-label">Deployed URL</label>
            <input type="url" class="input" id="deployed-link" placeholder="https://your-project.com" value="${submission.deployed || ''}" onchange="aiResumeBuilder.updateArtifact('deployed', this.value)">
            <div class="form-help">Required to mark as shipped</div>
          </div>
        </div>
      </div>
    `;
  }

  getFinalSubmissionSection() {
    const submission = this.loadSubmissionData();
    
    return `
      <div class="proof-section">
        <h2 class="proof-section-title">B) Final Submission Export</h2>
        <div class="submission-form">
          <div class="submission-preview">
            <h3>Preview</h3>
            <div class="submission-content">
              <div class="submission-header">AI Resume Builder — Final Submission</div>
              <div class="submission-details">
                <div class="submission-item">
                  <strong>Lovable Project:</strong> ${submission.lovable || 'Not provided'}
                </div>
                <div class="submission-item">
                  <strong>GitHub Repository:</strong> ${submission.github || 'Not provided'}
                </div>
                <div class="submission-item">
                  <strong>Live Deployment:</strong> ${submission.deployed || 'Not provided'}
                </div>
              </div>
            </div>
          </div>
          
          <div class="submission-actions">
            <button class="btn btn-primary" onclick="aiResumeBuilder.copyFinalSubmission()">📋 Copy Final Submission</button>
            <button class="btn btn-secondary" onclick="aiResumeBuilder.markAsShipped()">🚀 Mark as Shipped</button>
          </div>
        </div>
      </div>
    `;
  }

  getShippedStatusSection() {
    const isShipped = this.isShipped();
    
    return `
      <div class="proof-section">
        <h2 class="proof-section-title">C) Shipped Status</h2>
        <div class="shipped-status">
          <div class="status-badge ${isShipped ? 'shipped' : 'in-progress'}">
            ${isShipped ? '🚀 Project Shipped' : '⏳ In Progress'}
          </div>
          <div class="status-details">
            ${isShipped ? 
              '<p class="success-message">Project 3 Shipped Successfully.</p>' :
              '<p class="info-message">Complete all requirements to mark as shipped.</p>'
            }
          </div>
        </div>
      </div>
    `;
  }

  copyResumeAsText() { /* ... */ }
  showNotification(message) { /* ... */ }
}

  // Helper Methods (keep unchanged)
  handleSkillKeydown(event, category, index) { /* ... */ }
  addSkill(category, skill) { /* ... */ }
  removeSkill(category, index) { /* ... */ }
  updateSkill(category, index, value) {
    this.resumeData.skills[category][index] = value;
    this.autosave();
    this.updatePreview();
    this.calculateATSScore();
    this.updateATSDisplay();
  }
  updateSkillsDisplay() { /* ... */ }
  toggleSkillCategory(category) { /* ... */ }
  suggestSkills(category) { /* ... */ }
  isTechnicalSkill(skill) { /* ... */ }
  isSoftSkill(skill) { /* ... */ }
  isToolSkill(skill) { /* ... */ }
  updateProjectsDisplay() { /* ... */ }
  addProject() { /* ... */ }
  removeProject(index) { /* ... */ }
  updateProject(index, field, value) { /* ... */ }
  toggleProject(index) { /* ... */ }
  updateProjectsDisplay() { /* ... */ }
  }
}

// Initialize the app when DOM is ready
let aiResumeBuilder;
document.addEventListener('DOMContentLoaded', () => {
  aiResumeBuilder = new AIResumeBuilder();
});

// Export for global access
window.aiResumeBuilder = aiResumeBuilder;
