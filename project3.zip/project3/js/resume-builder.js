// AI Resume Builder - Premium Web Application with ATS Scoring & Templates

class AIResumeBuilder {
  constructor() {
    this.currentRoute = '/';
    this.selectedTemplate = 'classic';
    this.selectedColor = 'teal';
    this.resumeData = {
      personal: {
        name: '',
        email: '',
        phone: '',
        location: ''
      },
      summary: '',
      education: [],
      experience: [],
      projects: [],
      skills: {
        technical: [],
        soft: [],
        tools: []
      },
      links: {
        github: '',
        linkedin: ''
      }
    };
    this.atsScore = 0;
    this.suggestions = [];
    this.improvements = [];
    this.autosaveTimer = null;
    this.collapsedProjects = new Set();
    this.init();
  }

  init() {
    this.loadDataFromStorage();
    this.setupRouting();
    this.render();
    this.attachEventListeners();
    this.calculateATSScore();
    this.calculateImprovements();
  }

  setupRouting() {
    window.addEventListener('hashchange', () => {
      this.currentRoute = window.location.hash || '/';
      this.render();
    });
  }

  getRoute() {
    return window.location.hash || '/';
  }

  // LocalStorage Methods
  saveDataToStorage() {
    try {
      const dataToSave = {
        resumeData: this.resumeData,
        selectedTemplate: this.selectedTemplate
      };
      localStorage.setItem('resumeBuilderData', JSON.stringify(dataToSave));
    } catch (error) {
      console.warn('Failed to save data to localStorage:', error);
    }
  }

  loadDataFromStorage() {
    try {
      const savedData = localStorage.getItem('resumeBuilderData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        this.resumeData = parsed.resumeData || this.resumeData;
        this.selectedTemplate = parsed.selectedTemplate || 'classic';
        
        // Migrate old skills format to new format
        if (typeof this.resumeData.skills === 'string') {
          const oldSkills = this.resumeData.skills.split(',').map(skill => skill.trim()).filter(skill => skill.length > 0);
          this.resumeData.skills = {
            technical: oldSkills.filter(skill => this.isTechnicalSkill(skill)),
            soft: oldSkills.filter(skill => this.isSoftSkill(skill)),
            tools: oldSkills.filter(skill => this.isToolSkill(skill))
          };
        }
      }
    } catch (error) {
      console.warn('Failed to load data from localStorage:', error);
    }
  }

  isTechnicalSkill(skill) {
    const technicalSkills = ['JavaScript', 'Python', 'React', 'Node.js', 'TypeScript', 'PostgreSQL', 'MongoDB', 'GraphQL', 'Docker', 'Kubernetes', 'AWS', 'Git', 'Express', 'Redis'];
    return technicalSkills.some(tech => skill.toLowerCase().includes(tech.toLowerCase()));
  }

  isSoftSkill(skill) {
    const softSkills = ['Team Leadership', 'Problem Solving', 'Communication', 'Project Management', 'Mentoring', 'Collaboration', 'Critical Thinking'];
    return softSkills.some(soft => skill.toLowerCase().includes(soft.toLowerCase()));
  }

  isToolSkill(skill) {
    const toolSkills = ['Git', 'Docker', 'AWS', 'Kubernetes', 'Jira', 'VS Code', 'Figma', 'Chrome DevTools'];
    return toolSkills.some(tool => skill.toLowerCase().includes(tool.toLowerCase()));
  }

  autosave() {
    clearTimeout(this.autosaveTimer);
    this.autosaveTimer = setTimeout(() => {
      this.saveDataToStorage();
    }, 500); // Save after 500ms of inactivity
  }

  // Template Methods
  switchTemplate(template) {
    this.selectedTemplate = template;
    this.autosave();
    this.updateTemplateDisplay();
  }

  updateTemplateDisplay() {
    const previewPanel = document.querySelector('.preview-panel');
    if (previewPanel) {
      previewPanel.className = `preview-panel template-${this.selectedTemplate}`;
    }
    
    // Update tab states
    const tabs = document.querySelectorAll('.template-tab');
    tabs.forEach(tab => {
      tab.classList.toggle('active', tab.dataset.template === this.selectedTemplate);
    });
  }

  render() {
    const appContainer = document.getElementById('app');
    if (!appContainer) return;

    const route = this.getRoute();
    let content = '';

    switch (route) {
      case '/':
      case '#/':
        content = this.getHomePage();
        break;
      case '#/builder':
        content = this.getBuilderPage();
        break;
      case '#/preview':
        content = this.getPreviewPage();
        break;
      case '#/proof':
        content = this.getProofPage();
        break;
      default:
        content = this.getHomePage();
    }

    appContainer.innerHTML = content;
    this.attachEventListeners();
    this.updateNavigation();
  }

  getNavigation() {
    return `
      <nav class="top-nav">
        <div class="nav-links">
          <a href="#/" class="nav-link">Home</a>
          <a href="#/builder" class="nav-link">Builder</a>
          <a href="#/preview" class="nav-link">Preview</a>
          <a href="#/proof" class="nav-link">Proof</a>
        </div>
      </nav>
    `;
  }

  updateNavigation() {
    const route = this.getRoute();
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
      const href = link.getAttribute('href');
      if (href === route || (route === '/' && href === '#/')) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }

  getHomePage() {
    return `
      ${this.getNavigation()}
      <main class="main-content">
        <div class="home-container">
          <h1 class="home-headline">Build a Resume That Gets Read.</h1>
          <p class="home-subtitle">Create a professional, ATS-optimized resume that highlights your skills and experience with our AI-powered builder.</p>
          <a href="#/builder" class="cta-button">Start Building</a>
        </div>
      </main>
    `;
  }

  getBuilderPage() {
    return `
      ${this.getNavigation()}
      <main class="main-content">
        <div class="builder-container">
          <div class="builder-form">
            <div class="card">
              <h2 class="card-title">Resume Builder</h2>
              
              ${this.getTemplateTabs()}
              ${this.getATSScoreMeter()}
              ${this.getImprovementPanel()}
              
              ${this.getPersonalInfoSection()}
              ${this.getSummarySection()}
              ${this.getEducationSection()}
              ${this.getExperienceSection()}
              ${this.getProjectsSection()}
              ${this.getSkillsSection()}
              ${this.getLinksSection()}
              
              <div class="btn-group">
                <button class="btn btn-secondary" onclick="aiResumeBuilder.loadSampleData()">Load Sample Data</button>
              </div>
            </div>
          </div>
          
          <div class="builder-preview">
            <div class="preview-panel template-${this.selectedTemplate}">
              ${this.getLivePreview()}
            </div>
          </div>
        </div>
      </main>
    `;
  }

  getTemplateTabs() {
    return `
      <div class="template-tabs">
        <button class="template-tab ${this.selectedTemplate === 'classic' ? 'active' : ''}" 
                data-template="classic" onclick="aiResumeBuilder.switchTemplate('classic')">
          Classic
        </button>
        <button class="template-tab ${this.selectedTemplate === 'modern' ? 'active' : ''}" 
                data-template="modern" onclick="aiResumeBuilder.switchTemplate('modern')">
          Modern
        </button>
        <button class="template-tab ${this.selectedTemplate === 'minimal' ? 'active' : ''}" 
                data-template="minimal" onclick="aiResumeBuilder.switchTemplate('minimal')">
          Minimal
        </button>
      </div>
    `;
  }

  getImprovementPanel() {
    if (this.improvements.length === 0) return '';
    
    return `
      <div class="improvement-panel">
        <div class="improvement-title">Top 3 Improvements</div>
        <ul class="improvement-list">
          ${this.improvements.slice(0, 3).map((improvement, index) => `
            <li class="improvement-item">
              <span class="improvement-number">${index + 1}</span>
              <span>${improvement}</span>
            </li>
          `).join('')}
        </ul>
      </div>
    `;
  }

  getATSScoreMeter() {
    const scoreClass = this.atsScore >= 80 ? 'high' : this.atsScore >= 50 ? 'medium' : 'low';
    const scoreFill = Math.min(this.atsScore, 100);
    
    return `
      <div class="ats-score-container">
        <div class="ats-score-header">
          <div class="ats-score-title">ATS Readiness Score</div>
          <div class="ats-score-value ${scoreClass}">${this.atsScore}</div>
        </div>
        <div class="ats-score-bar">
          <div class="ats-score-fill ${scoreClass}" style="width: ${scoreFill}%"></div>
        </div>
        ${this.suggestions.length > 0 ? `
          <div class="ats-suggestions">
            ${this.suggestions.slice(0, 3).map((suggestion, index) => `
              <div class="ats-suggestion">
                <span class="ats-suggestion-icon">•</span>
                <span>${suggestion}</span>
              </div>
            `).join('')}
          </div>
        ` : ''}
      </div>
    `;
  }

  // ATS Scoring Algorithm
  calculateATSScore() {
    let score = 0;
    const newSuggestions = [];

    // +15 if summary length is 40–120 words
    const summaryWords = this.resumeData.summary.trim().split(/\s+/).filter(word => word.length > 0).length;
    if (summaryWords >= 40 && summaryWords <= 120) {
      score += 15;
    } else if (summaryWords > 0) {
      newSuggestions.push(summaryWords < 40 ? 
        'Write a stronger summary (target 40-120 words).' : 
        'Shorten your summary (target 40-120 words).'
      );
    } else {
      newSuggestions.push('Add a professional summary (40-120 words).');
    }

    // +10 if at least 2 projects
    if (this.resumeData.projects.length >= 2) {
      score += 10;
    } else if (this.resumeData.projects.length === 1) {
      newSuggestions.push('Add at least one more project (target 2+).');
    } else {
      newSuggestions.push('Add at least 2 projects.');
    }

    // +10 if at least 1 experience entry
    if (this.resumeData.experience.length >= 1) {
      score += 10;
    } else {
      newSuggestions.push('Add at least 1 work experience entry.');
    }

    // +10 if skills list has ≥ 8 items
    const skillsList = this.resumeData.skills.split(',').map(skill => skill.trim()).filter(skill => skill.length > 0);
    if (skillsList.length >= 8) {
      score += 10;
    } else if (skillsList.length > 0) {
      newSuggestions.push(`Add more skills (currently ${skillsList.length}, target 8+).`);
    } else {
      newSuggestions.push('Add technical skills (target 8+).');
    }

    // +10 if GitHub or LinkedIn link exists
    if (this.resumeData.links.github || this.resumeData.links.linkedin) {
      score += 10;
    } else {
      newSuggestions.push('Add GitHub or LinkedIn profile link.');
    }

    // +15 if any experience/project bullet contains a number (%, X, k, etc.)
    const hasNumbers = this.resumeData.experience.some(exp => 
      this.containsNumber(exp.description) || this.containsNumber(exp.title)
    ) || this.resumeData.projects.some(project => 
      this.containsNumber(project.description) || this.containsNumber(project.name)
    );
    
    if (hasNumbers) {
      score += 15;
    } else {
      newSuggestions.push('Add measurable impact with numbers (%, k, X, etc.) in descriptions.');
    }

    // +10 if education section has complete fields
    const hasCompleteEducation = this.resumeData.education.some(edu => 
      edu.degree && edu.institution && edu.year
    );
    if (hasCompleteEducation) {
      score += 10;
    } else if (this.resumeData.education.length > 0) {
      newSuggestions.push('Complete all education fields (degree, institution, year).');
    } else {
      newSuggestions.push('Add education information.');
    }

    // Cap at 100
    this.atsScore = Math.min(score, 100);
    this.suggestions = newSuggestions;
  }

  // Bullet Guidance Methods
  checkBulletStructure(text) {
    if (!text || !text.trim()) return { hasActionVerb: false, hasNumbers: false };
    
    const actionVerbs = [
      'Built', 'Developed', 'Designed', 'Implemented', 'Led', 'Improved', 
      'Created', 'Optimized', 'Automated', 'Managed', 'Launched', 
      'Reduced', 'Increased', 'Generated', 'Achieved', 'Completed',
      'Coordinated', 'Mentored', 'Trained', 'Supported', 'Analyzed',
      'Researched', 'Documented', 'Tested', 'Deployed', 'Maintained'
    ];
    
    const words = text.trim().split(/\s+/);
    const firstWord = words[0] ? words[0].replace(/[^\w]/g, '') : '';
    const hasActionVerb = actionVerbs.some(verb => 
      firstWord.toLowerCase() === verb.toLowerCase() || 
      text.trim().startsWith(verb)
    );
    
    const hasNumbers = /\d+[%kmb]|%\d+|\d+k|\d+m|\d+b/i.test(text);
    
    return { hasActionVerb, hasNumbers };
  }

  getBulletGuidance(text) {
    const { hasActionVerb, hasNumbers } = this.checkBulletStructure(text);
    const guidance = [];
    
    if (!hasActionVerb) {
      guidance.push('Start with a strong action verb.');
    }
    
    if (!hasNumbers) {
      guidance.push('Add measurable impact (numbers).');
    }
    
    return guidance;
  }

  // Improvement Calculation
  calculateImprovements() {
    const improvements = [];
    
    // Check projects count
    if (this.resumeData.projects.length < 2) {
      improvements.push('Add more projects to showcase your skills (target 2+).');
    }
    
    // Check for numbers in experience/projects
    const hasNumbers = this.resumeData.experience.some(exp => 
      this.containsNumber(exp.description) || this.containsNumber(exp.title)
    ) || this.resumeData.projects.some(project => 
      this.containsNumber(project.description) || this.containsNumber(project.name)
    );
    
    if (!hasNumbers) {
      improvements.push('Add measurable impact with numbers (%, k, X, etc.) in experience/project descriptions.');
    }
    
    // Check summary length
    const summaryWords = this.resumeData.summary.trim().split(/\s+/).filter(word => word.length > 0).length;
    if (summaryWords < 40) {
      improvements.push('Expand your professional summary (target 40-120 words).');
    }
    
    // Check skills count
    const skillsList = this.resumeData.skills.split(',').map(skill => skill.trim()).filter(skill => skill.length > 0);
    if (skillsList.length < 8) {
      improvements.push(`Add more technical skills (currently ${skillsList.length}, target 8+).`);
    }
    
    // Check experience
    if (this.resumeData.experience.length === 0) {
      improvements.push('Add work experience or significant projects to demonstrate your capabilities.');
    }
    
    this.improvements = improvements;
  }

  getPersonalInfoSection() {
    return `
      <div class="form-section">
        <h3 class="form-section-title">Personal Information</h3>
        <div class="form-group">
          <label class="form-label">Full Name</label>
          <input type="text" class="input" id="name" value="${this.resumeData.personal.name}" onchange="aiResumeBuilder.updatePersonalInfo('name', this.value)">
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <input type="email" class="input" id="email" value="${this.resumeData.personal.email}" onchange="aiResumeBuilder.updatePersonalInfo('email', this.value)">
        </div>
        <div class="form-group">
          <label class="form-label">Phone</label>
          <input type="tel" class="input" id="phone" value="${this.resumeData.personal.phone}" onchange="aiResumeBuilder.updatePersonalInfo('phone', this.value)">
        </div>
        <div class="form-group">
          <label class="form-label">Location</label>
          <input type="text" class="input" id="location" value="${this.resumeData.personal.location}" onchange="aiResumeBuilder.updatePersonalInfo('location', this.value)">
        </div>
      </div>
    `;
  }

  getSummarySection() {
    return `
      <div class="form-section">
        <h3 class="form-section-title">Professional Summary</h3>
        <div class="form-group">
          <textarea class="input textarea" id="summary" placeholder="Write a brief summary of your professional background and goals..." onchange="aiResumeBuilder.updateSummary(this.value)">${this.resumeData.summary}</textarea>
        </div>
      </div>
    `;
  }

  getEducationSection() {
    return `
      <div class="form-section">
        <h3 class="form-section-title">Education</h3>
        <div id="education-entries">
          ${this.resumeData.education.map((edu, index) => this.getEducationEntry(edu, index)).join('')}
        </div>
        <button class="btn btn-secondary" onclick="aiResumeBuilder.addEducation()">+ Add Education</button>
      </div>
    `;
  }

  getEducationEntry(education, index) {
    return `
      <div class="dynamic-entry">
        <div class="entry-header">
          <span class="entry-title">Education ${index + 1}</span>
          <button class="remove-btn" onclick="aiResumeBuilder.removeEducation(${index})">Remove</button>
        </div>
        <div class="form-group">
          <label class="form-label">Degree</label>
          <input type="text" class="input" value="${education.degree || ''}" onchange="aiResumeBuilder.updateEducation(${index}, 'degree', this.value)">
        </div>
        <div class="form-group">
          <label class="form-label">Institution</label>
          <input type="text" class="input" value="${education.institution || ''}" onchange="aiResumeBuilder.updateEducation(${index}, 'institution', this.value)">
        </div>
        <div class="form-group">
          <label class="form-label">Year</label>
          <input type="text" class="input" value="${education.year || ''}" onchange="aiResumeBuilder.updateEducation(${index}, 'year', this.value)">
        </div>
      </div>
    `;
  }

  getExperienceSection() {
    return `
      <div class="form-section">
        <h3 class="form-section-title">Work Experience</h3>
        <div id="experience-entries">
          ${this.resumeData.experience.map((exp, index) => this.getExperienceEntry(exp, index)).join('')}
        </div>
        <button class="btn btn-secondary" onclick="aiResumeBuilder.addExperience()">+ Add Experience</button>
      </div>
    `;
  }

  getExperienceEntry(experience, index) {
    const guidance = this.getBulletGuidance(experience.description);
    
    return `
      <div class="dynamic-entry">
        <div class="entry-header">
          <span class="entry-title">Experience ${index + 1}</span>
          <button class="remove-btn" onclick="aiResumeBuilder.removeExperience(${index})">Remove</button>
        </div>
        <div class="form-group">
          <label class="form-label">Job Title</label>
          <input type="text" class="input" value="${experience.title || ''}" onchange="aiResumeBuilder.updateExperience(${index}, 'title', this.value)">
        </div>
        <div class="form-group">
          <label class="form-label">Company</label>
          <input type="text" class="input" value="${experience.company || ''}" onchange="aiResumeBuilder.updateExperience(${index}, 'company', this.value)">
        </div>
        <div class="form-group">
          <label class="form-label">Duration</label>
          <input type="text" class="input" placeholder="e.g., Jan 2020 - Present" value="${experience.duration || ''}" onchange="aiResumeBuilder.updateExperience(${index}, 'duration', this.value)">
        </div>
        <div class="form-group form-textarea-with-guidance">
          <label class="form-label">Description</label>
          <textarea class="input textarea" onchange="aiResumeBuilder.updateExperience(${index}, 'description', this.value)">${experience.description || ''}</textarea>
          ${guidance.length > 0 ? `
            <div class="bullet-suggestions">
              ${guidance.map(g => `<div class="bullet-guidance">${g}</div>`).join('')}
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  getProjectsSection() {
    return `
      <div class="form-section">
        <h3 class="form-section-title">Projects</h3>
        
        <div class="projects-accordion" id="projects-accordion">
          ${this.resumeData.projects.map((project, index) => this.getProjectEntry(project, index)).join('')}
        </div>
        
        <button class="btn btn-secondary" onclick="aiResumeBuilder.addProject()">+ Add Project</button>
      </div>
    `;
  }

  getProjectEntry(project, index) {
    const isCollapsed = this.collapsedProjects.has(index);
    const charCount = (project.description || '').length;
    const charWarning = charCount > 200 ? 'warning' : '';
    
    return `
      <div class="project-entry ${isCollapsed ? 'collapsed' : ''}">
        <div class="project-header" onclick="aiResumeBuilder.toggleProject(${index})">
          <div class="project-title">${project.name || 'Project ' + (index + 1)}</div>
          <div class="project-actions">
            <button class="project-toggle">${isCollapsed ? '+' : '−'}</button>
            <button class="project-delete" onclick="aiResumeBuilder.removeProject(${index})">×</button>
          </div>
        </div>
        
        <div class="project-content" style="display: ${isCollapsed ? 'none' : 'block'}">
          <div class="project-form-group">
            <label class="project-label">Project Title</label>
            <input type="text" class="project-input" value="${project.name || ''}" onchange="aiResumeBuilder.updateProject(${index}, 'title', this.value)">
          </div>
          
          <div class="project-form-group">
            <label class="project-label">Description</label>
            <textarea class="project-input project-textarea" maxlength="200" onchange="aiResumeBuilder.updateProject(${index}, 'description', this.value)">${project.description || ''}</textarea>
            <div class="char-counter ${charWarning}">
              ${charCount}/200 characters
            </div>
          </div>
          
          <div class="project-form-group">
            <label class="project-label">Tech Stack</label>
            <input type="text" class="project-input" placeholder="e.g., React, Node.js, MongoDB" value="${project.technologies || ''}" onchange="aiResumeBuilder.updateProject(${index}, 'technologies', this.value)">
          </div>
          
          <div class="project-links">
            <div class="project-link-group">
              <label class="project-label">Live URL</label>
              <input type="url" class="project-input" placeholder="https://your-project.com" value="${project.liveUrl || ''}" onchange="aiResumeBuilder.updateProject(${index}, 'liveUrl', this.value)">
            </div>
            <div class="project-link-group">
              <label class="project-label">GitHub URL</label>
              <input type="url" class="project-input" placeholder="https://github.com/username/repo" value="${project.githubUrl || ''}" onchange="aiResumeBuilder.updateProject(${index}, 'githubUrl', this.value)">
            </div>
          </div>
        </div>
      </div>
    `;
  }

  toggleProject(index) {
    if (this.collapsedProjects.has(index)) {
      this.collapsedProjects.delete(index);
    } else {
      this.collapsedProjects.add(index);
    }
    this.updateProjectsDisplay();
  }

  addProject() {
    this.resumeData.projects.push({ 
      name: '', 
      description: '', 
      technologies: '', 
      liveUrl: '', 
      githubUrl: '' 
    });
    this.autosave();
    this.updateProjectsDisplay();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  removeProject(index) {
    this.resumeData.projects.splice(index, 1);
    this.collapsedProjects.delete(index);
    this.autosave();
    this.updateProjectsDisplay();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  updateProject(index, field, value) {
    this.resumeData.projects[index][field] = value;
    this.autosave();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  updateProjectsDisplay() {
    const projectsContainer = document.getElementById('projects-accordion');
    if (projectsContainer) {
      projectsContainer.innerHTML = this.resumeData.projects.map((project, index) => this.getProjectEntry(project, index)).join('');
    }
  }
    return `
      <div class="form-section">
        <h3 class="form-section-title">Skills</h3>
        
        <div class="skills-accordion">
          ${this.getSkillCategory('Technical Skills', 'technical', [
            'TypeScript', 'React', 'Node.js', 'PostgreSQL', 'GraphQL'
          ])}
          
          ${this.getSkillCategory('Soft Skills', 'soft', [
            'Team Leadership', 'Problem Solving'
          ])}
          
          ${this.getSkillCategory('Tools & Technologies', 'tools', [
            'Git', 'Docker', 'AWS'
          ])}
        </div>
      </div>
    `;
  }

  getSkillCategory(title, category, suggestedSkills) {
    const skills = this.resumeData.skills[category] || [];
    const skillCount = skills.length;
    
    let html = '<div class="skill-category">';
    html += '<div class="skill-category-header" onclick="aiResumeBuilder.toggleSkillCategory(\'' + category + '\')">';
    html += '<div class="skill-category-title">' + title + '</div>';
    html += '<div class="skill-count">' + skillCount + '</div>';
    html += '</div>';
    html += '<div class="skill-category-content" id="skill-' + category + '">';
    html += '<div class="skill-input-container">';
    
    skills.forEach((skill, index) => {
      html += '<div class="skill-input-wrapper">';
      html += '<input type="text" class="skill-input" value="' + skill + '" placeholder="Type a skill and press Enter" ';
      html += 'onkeydown="aiResumeBuilder.handleSkillKeydown(event, \'' + category + '\', ' + index + ')" ';
      html += 'onchange="aiResumeBuilder.updateSkill(\'' + category + '\', ' + index + ', this.value)">';
      html += '<button class="skill-remove" onclick="aiResumeBuilder.removeSkill(\'' + category + '\', ' + index + ')">×</button>';
      html += '</div>';
    });
    
    html += '</div>';
    html += '<button class="suggest-skills-btn" onclick="aiResumeBuilder.suggestSkills(\'' + category + '\')">';
    html += '✨ Suggest Skills';
    html += '</button>';
    html += '</div>';
    html += '</div>';
    
    return html;
  }

  toggleSkillCategory(category) {
    const content = document.getElementById(`skill-${category}`);
    if (content) {
      content.style.display = content.style.display === 'none' ? 'block' : 'none';
    }
  }

  handleSkillKeydown(event, category, index) {
    if (event.key === 'Enter') {
      event.preventDefault();
      const input = event.target;
      const value = input.value.trim();
      if (value) {
        this.addSkill(category, value);
        input.value = '';
      }
    } else if (event.key === 'Backspace' && !event.target.value) {
      // Remove last skill if backspace pressed on empty input
      this.removeSkill(category, this.resumeData.skills[category].length - 1);
    }
  }

  addSkill(category, skill) {
    if (skill && !this.resumeData.skills[category].includes(skill)) {
      this.resumeData.skills[category].push(skill);
      this.autosave();
      this.updateSkillsDisplay();
      this.calculateATSScore();
      this.calculateImprovements();
      this.updateATSDisplay();
      this.updateImprovementDisplay();
    }
  }

  removeSkill(category, index) {
    this.resumeData.skills[category].splice(index, 1);
    this.autosave();
    this.updateSkillsDisplay();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  updateSkill(category, index, value) {
    this.resumeData.skills[category][index] = value;
    this.autosave();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  updateSkillsDisplay() {
    const skillsContainer = document.querySelector('.skills-accordion');
    if (skillsContainer) {
      skillsContainer.innerHTML = this.getSkillsSection();
    }
  }

  suggestSkills(category) {
    const button = event.target;
    button.classList.add('loading');
    button.textContent = 'Loading...';
    
    // Simulate loading delay
    setTimeout(() => {
      const suggestions = {
        technical: ['TypeScript', 'React', 'Node.js', 'PostgreSQL', 'GraphQL'],
        soft: ['Team Leadership', 'Problem Solving'],
        tools: ['Git', 'Docker', 'AWS']
      };
      
      const categorySkills = suggestions[category] || [];
      categorySkills.forEach(skill => {
        if (!this.resumeData.skills[category].includes(skill)) {
          this.resumeData.skills[category].push(skill);
        }
      });
      
      this.autosave();
      this.updateSkillsDisplay();
      this.calculateATSScore();
      this.calculateImprovements();
      this.updateATSDisplay();
      this.updateImprovementDisplay();
    }, 1000);
  }

  getLinksSection() {
    return `
      <div class="form-section">
        <h3 class="form-section-title">Links</h3>
        <div class="form-group">
          <label class="form-label">GitHub</label>
          <input type="url" class="input" placeholder="https://github.com/username" value="${this.resumeData.links.github}" onchange="aiResumeBuilder.updateLinks('github', this.value)">
        </div>
        <div class="form-group">
          <label class="form-label">LinkedIn</label>
          <input type="url" class="input" placeholder="https://linkedin.com/in/username" value="${this.resumeData.links.linkedin}" onchange="aiResumeBuilder.updateLinks('linkedin', this.value)">
        </div>
      </div>
    `;
  }

  getLivePreview() {
    const { personal, summary, education, experience, projects, skills, links } = this.resumeData;
    
    let content = '';
    
    // Header
    content += `
      <div class="preview-header">
        <div class="preview-name">${personal.name || 'Your Name'}</div>
        <div class="preview-contact">
          ${personal.email ? `${personal.email} • ` : ''}
          ${personal.phone ? `${personal.phone} • ` : ''}
          ${personal.location || 'Location'}
          ${links.github ? `• ${links.github}` : ''}
          ${links.linkedin ? `• ${links.linkedin}` : ''}
        </div>
      </div>
    `;
    
    // Summary Section
    if (summary.trim()) {
      content += `
        <div class="preview-section">
          <h3 class="preview-section-title">Summary</h3>
          <div class="preview-item-description">${summary}</div>
        </div>
      `;
    }
    
    // Experience Section
    if (experience.length > 0 && experience.some(exp => exp.title || exp.company)) {
      content += `
        <div class="preview-section">
          <h3 class="preview-section-title">Experience</h3>
          ${experience.filter(exp => exp.title || exp.company).map(exp => `
            <div class="preview-item">
              <div class="preview-item-title">${exp.title || 'Job Title'}</div>
              <div class="preview-item-subtitle">
                ${exp.company || 'Company'} ${exp.duration ? `• ${exp.duration}` : ''}
              </div>
              ${exp.description ? `<div class="preview-item-description">${exp.description}</div>` : ''}
            </div>
          `).join('')}
        </div>
      `;
    }
    
    // Education Section
    if (education.length > 0 && education.some(edu => edu.degree || edu.institution)) {
      content += `
        <div class="preview-section">
          <h3 class="preview-section-title">Education</h3>
          ${education.filter(edu => edu.degree || edu.institution).map(edu => `
            <div class="preview-item">
              <div class="preview-item-title">${edu.degree || 'Degree'}</div>
              <div class="preview-item-subtitle">
                ${edu.institution || 'Institution'} ${edu.year ? `• ${edu.year}` : ''}
              </div>
            </div>
          `).join('')}
        </div>
      `;
    }
    
    // Projects Section
    if (projects.length > 0 && projects.some(project => project.name)) {
      content += `
        <div class="preview-section">
          <h3 class="preview-section-title">Projects</h3>
          ${projects.filter(project => project.name).map(project => `
            <div class="preview-item">
              <div class="preview-item-title">${project.name}</div>
              ${project.description ? `<div class="preview-item-description">${project.description}</div>` : ''}
              ${project.technologies ? `<div class="preview-item-tech">Technologies: ${project.technologies}</div>` : ''}
              ${project.liveUrl ? `<div class="preview-item-tech">🔗 Live: <a href="${project.liveUrl}" target="_blank">${project.liveUrl}</a></div>` : ''}
              ${project.githubUrl ? `<div class="preview-item-tech">📦 GitHub: <a href="${project.githubUrl}" target="_blank">${project.githubUrl}</a></div>` : ''}
            </div>
          `).join('')}
        </div>
      `;
    }
    
    // Skills Section
    if (skills.technical.length > 0 || skills.soft.length > 0 || skills.tools.length > 0) {
      content += `
        <div class="preview-section">
          <h3 class="preview-section-title">Skills</h3>
          <div class="preview-skills-list">
            ${skills.technical.map(skill => `<span class="preview-skill">${skill}</span>`).join('')}
            ${skills.soft.map(skill => `<span class="preview-skill">${skill}</span>`).join('')}
            ${skills.tools.map(skill => `<span class="preview-skill">${skill}</span>`).join('')}
          </div>
        </div>
      `;
    }
    
    // If no content, show empty state
    if (!content.includes('preview-section')) {
      content = `
        <div class="preview-header">
          <div class="preview-name">${personal.name || 'Your Name'}</div>
          <div class="preview-contact">
            ${personal.email || 'email@example.com'} • ${personal.phone || '+1 (555) 123-4567'} • ${personal.location || 'Location'}
          </div>
        </div>
        <div class="preview-empty">
          Start adding your resume information to see live preview here.
        </div>
      `;
    }
    
    return content;
  }

  getPreviewPage() {
    const { personal, summary, education, experience, projects, skills, links } = this.resumeData;
    const validationWarning = this.getValidationWarning();
    
    return `
      ${this.getNavigation()}
      <main class="main-content">
        <div class="preview-container">
          ${this.getTemplateTabs()}
          
          ${validationWarning}
          
          <div class="export-buttons">
            <button class="export-btn" onclick="aiResumeBuilder.printResume()">
              🖨️ Print / Save as PDF
            </button>
            <button class="export-btn secondary" onclick="aiResumeBuilder.copyResumeAsText()">
              📋 Copy Resume as Text
            </button>
          </div>
          
          <div class="preview-panel template-${this.selectedTemplate}">
            ${this.getLivePreview()}
          </div>
        </div>
      </main>
    `;
  }

  getValidationWarning() {
    const missingElements = [];
    
    if (!this.resumeData.personal.name.trim()) {
      missingElements.push('name');
    }
    
    if (this.resumeData.experience.length === 0 && this.resumeData.projects.length === 0) {
      missingElements.push('at least one project or experience entry');
    }
    
    if (missingElements.length === 0) return '';
    
    return `
      <div class="validation-warning">
        <div class="validation-warning-title">⚠️ Resume Completeness Warning</div>
        <div class="validation-warning-text">
          Your resume may look incomplete. Consider adding: ${missingElements.join(', ')}.
        </div>
      </div>
    `;
  }

  getProofPage() {
    return `
      ${this.getNavigation()}
      <main class="main-content">
        <div class="proof-container">
          <h1>Proof Page</h1>
          <div class="proof-placeholder">
            <h3>Artifacts Placeholder</h3>
            <p>This page will contain project artifacts and completion proof.</p>
            <p style="margin-top: 16px; color: var(--color-secondary-text);">
              Resume sections completed: ${this.getCompletedSectionsCount()}/7
            </p>
          </div>
        </div>
      </main>
    `;
  }

  getCompletedSectionsCount() {
    let count = 0;
    if (this.resumeData.personal.name) count++;
    if (this.resumeData.summary) count++;
    if (this.resumeData.education.length > 0) count++;
    if (this.resumeData.experience.length > 0) count++;
    if (this.resumeData.projects.length > 0) count++;
    if (this.resumeData.skills) count++;
    if (this.resumeData.links.github || this.resumeData.links.linkedin) count++;
    return count;
  }

  // Data update methods with autosave
  updatePersonalInfo(field, value) {
    this.resumeData.personal[field] = value;
    this.autosave();
    this.updatePreview();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  updateSummary(value) {
    this.resumeData.summary = value;
    this.autosave();
    this.updatePreview();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  addEducation() {
    this.resumeData.education.push({ degree: '', institution: '', year: '' });
    this.autosave();
    this.render();
  }

  removeEducation(index) {
    this.resumeData.education.splice(index, 1);
    this.autosave();
    this.render();
  }

  updateEducation(index, field, value) {
    this.resumeData.education[index][field] = value;
    this.autosave();
    this.updatePreview();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  addExperience() {
    this.resumeData.experience.push({ title: '', company: '', duration: '', description: '' });
    this.autosave();
    this.render();
  }

  removeExperience(index) {
    this.resumeData.experience.splice(index, 1);
    this.autosave();
    this.render();
  }

  updateExperience(index, field, value) {
    this.resumeData.experience[index][field] = value;
    this.autosave();
    this.updatePreview();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  addProject() {
    this.resumeData.projects.push({ 
      name: '', 
      description: '', 
      technologies: '', 
      liveUrl: '', 
      githubUrl: '' 
    });
    this.autosave();
    this.updateProjectsDisplay();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  removeProject(index) {
    this.resumeData.projects.splice(index, 1);
    this.collapsedProjects.delete(index);
    this.autosave();
    this.updateProjectsDisplay();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  updateProject(index, field, value) {
    this.resumeData.projects[index][field] = value;
    this.autosave();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  updateProjectsDisplay() {
    const projectsContainer = document.getElementById('projects-accordion');
    if (projectsContainer) {
      projectsContainer.innerHTML = this.resumeData.projects.map((project, index) => this.getProjectEntry(project, index)).join('');
    }
  }

  updateSkills(value) {
    // Handle migration from old string format to new object format
    if (typeof value === 'string') {
      const oldSkills = value.split(',').map(skill => skill.trim()).filter(skill => skill.length > 0);
      this.resumeData.skills = {
        technical: oldSkills.filter(skill => this.isTechnicalSkill(skill)),
        soft: oldSkills.filter(skill => this.isSoftSkill(skill)),
        tools: oldSkills.filter(skill => this.isToolSkill(skill))
      };
    } else {
      // Already in new format, update all categories
      const allSkills = value.technical.concat(value.soft, value.tools);
      this.resumeData.skills = value;
    }
    
    this.autosave();
    this.updatePreview();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  updateLinks(field, value) {
    this.resumeData.links[field] = value;
    this.autosave();
    this.updatePreview();
    this.calculateATSScore();
    this.calculateImprovements();
    this.updateATSDisplay();
    this.updateImprovementDisplay();
  }

  updateATSDisplay() {
    if (this.getRoute() === '#/builder') {
      const atsContainer = document.querySelector('.ats-score-container');
      if (atsContainer) {
        atsContainer.outerHTML = this.getATSScoreMeter();
      }
    }
  }

  updateImprovementDisplay() {
    if (this.getRoute() === '#/builder') {
      const improvementPanel = document.querySelector('.improvement-panel');
      if (improvementPanel) {
        improvementPanel.outerHTML = this.getImprovementPanel();
      } else {
        const atsContainer = document.querySelector('.ats-score-container');
        if (atsContainer && this.improvements.length > 0) {
          atsContainer.insertAdjacentHTML('afterend', this.getImprovementPanel());
        }
      }
    }
  }

  loadSampleData() {
    this.resumeData = {
      personal: {
        name: 'John Doe',
        email: 'john.doe@example.com',
        phone: '+1 (555) 123-4567',
        location: 'San Francisco, CA'
      },
      summary: 'Experienced software developer with 5+ years of expertise in full-stack web development. Passionate about creating scalable applications and leading cross-functional teams. Proven track record of delivering high-quality solutions that improve business metrics by 25%+.',
      education: [
        {
          degree: 'Bachelor of Science in Computer Science',
          institution: 'University of California, Berkeley',
          year: '2018'
        }
      ],
      experience: [
        {
          title: 'Senior Software Engineer',
          company: 'Tech Corp',
          duration: '2020 - Present',
          description: 'Led development of microservices architecture serving 1M+ users. Mentored junior developers and improved system performance by 40%. Reduced deployment time by 60% through CI/CD optimization.'
        }
      ],
      projects: [
        {
          name: 'E-commerce Platform',
          description: 'Built a full-stack e-commerce platform with React and Node.js, handling payments and inventory management. Increased conversion by 15% through UX improvements.',
          technologies: 'React, Node.js, MongoDB, Stripe API'
        },
        {
          name: 'AI Resume Builder',
          description: 'Developed an ATS-optimized resume builder with real-time scoring and suggestions. Helped 500+ users improve their resume quality.',
          technologies: 'JavaScript, CSS, HTML, ATS Algorithms'
        }
      ],
      skills: 'JavaScript, Python, React, Node.js, Express, MongoDB, PostgreSQL, Git, AWS, Docker, TypeScript, GraphQL, Redis, Kubernetes',
      links: {
        github: 'https://github.com/johndoe',
        linkedin: 'https://linkedin.com/in/johndoe'
      }
    };
    
    this.autosave();
    this.render();
    this.calculateATSScore();
    this.calculateImprovements();
    this.showNotification('Sample data loaded successfully!');
  }

  updatePreview() {
    if (this.getRoute() === '#/builder') {
      const previewPanel = document.querySelector('.preview-panel');
      if (previewPanel) {
        previewPanel.innerHTML = this.getLivePreview();
        this.updateTemplateDisplay();
      }
    }
  }

  attachEventListeners() {
    // Event listeners are attached inline in the HTML
  }

  // Export Methods
  printResume() {
    // Trigger browser print dialog
    window.print();
  }

  copyResumeAsText() {
    const { personal, summary, education, experience, projects, skills, links } = this.resumeData;
    
    let textResume = '';
    
    // Name and Contact
    if (personal.name) {
      textResume += `${personal.name.toUpperCase()}\n`;
      textResume += `${personal.email || ''} ${personal.phone || ''} ${personal.location || ''}\n`;
      if (links.github) textResume += `${links.github}\n`;
      if (links.linkedin) textResume += `${links.linkedin}\n`;
      textResume += '\n';
    }
    
    // Summary
    if (summary.trim()) {
      textResume += 'SUMMARY\n';
      textResume += '-------\n';
      textResume += `${summary}\n\n`;
    }
    
    // Experience
    if (experience.length > 0) {
      textResume += 'EXPERIENCE\n';
      textResume += '----------\n';
      experience.filter(exp => exp.title || exp.company).forEach(exp => {
        textResume += `${exp.title || 'Job Title'}\n`;
        textResume += `${exp.company || 'Company'} ${exp.duration ? `• ${exp.duration}` : ''}\n`;
        if (exp.description) {
          textResume += `${exp.description}\n`;
        }
        textResume += '\n';
      });
    }
    
    // Projects
    if (projects.length > 0) {
      textResume += 'PROJECTS\n';
      textResume += '--------\n';
      projects.filter(project => project.name).forEach(project => {
        textResume += `${project.name}\n`;
        if (project.description) {
          textResume += `${project.description}\n`;
        }
        if (project.technologies) {
          textResume += `Technologies: ${project.technologies}\n`;
        }
        textResume += '\n';
      });
    }
    
    // Education
    if (education.length > 0) {
      textResume += 'EDUCATION\n';
      textResume += '---------\n';
      education.filter(edu => edu.degree || edu.institution).forEach(edu => {
        textResume += `${edu.degree || 'Degree'}\n`;
        textResume += `${edu.institution || 'Institution'} ${edu.year ? `• ${edu.year}` : ''}\n`;
        textResume += '\n';
      });
    }
    
    // Skills
    if (skills.trim()) {
      textResume += 'SKILLS\n';
      textResume += '------\n';
      textResume += `${skills}\n\n`;
    }
    
    // Copy to clipboard
    navigator.clipboard.writeText(textResume).then(() => {
      this.showNotification('Resume copied to clipboard as plain text!');
    }).catch(err => {
      console.error('Failed to copy resume:', err);
      this.showNotification('Failed to copy resume. Please try again.');
    });
  }

  showNotification(message) {
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: var(--color-accent);
      color: white;
      padding: 12px 16px;
      border-radius: 4px;
      z-index: 1000;
      font-size: 14px;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      if (document.body.contains(notification)) {
        document.body.removeChild(notification);
      }
    }, 3000);
  }
}

// Initialize the app when DOM is ready
let aiResumeBuilder;
document.addEventListener('DOMContentLoaded', () => {
  aiResumeBuilder = new AIResumeBuilder();
});

// Export for global access
window.aiResumeBuilder = aiResumeBuilder;
