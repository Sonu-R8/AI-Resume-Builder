// AI Resume Builder - Build Track JavaScript Components

class AIResumeBuilder {
  constructor() {
    this.currentStep = 1;
    this.totalSteps = 8;
    this.status = 'not-started';
    this.artifacts = {};
    this.stepCompleted = {};
    this.currentRoute = window.location.hash || '#rb/01-problem';
    this.init();
  }

  init() {
    this.setupRouting();
    this.render();
    this.attachEventListeners();
  }

  setupRouting() {
    window.addEventListener('hashchange', () => {
      this.currentRoute = window.location.hash || '#rb/01-problem';
      this.render();
    });
  }

  getCurrentStepFromRoute() {
    const routeMap = {
      '#rb/01-problem': 1,
      '#rb/02-market': 2,
      '#rb/03-architecture': 3,
      '#rb/04-hld': 4,
      '#rb/05-lld': 5,
      '#rb/06-build': 6,
      '#rb/07-test': 7,
      '#rb/08-ship': 8,
      '#rb/proof': 'proof'
    };
    
    return routeMap[this.currentRoute] || 1;
  }

  canAccessStep(step) {
    if (step === 'proof') {
      return Object.values(this.stepCompleted).filter(Boolean).length === this.totalSteps;
    }
    
    if (step === 1) return true;
    
    for (let i = 1; i < step; i++) {
      if (!this.stepCompleted[i]) {
        return false;
      }
    }
    return true;
  }

  render() {
    const appContainer = document.getElementById('app');
    if (!appContainer) return;

    appContainer.innerHTML = this.getLayoutHTML();
  }

  getLayoutHTML() {
    return `
      <div class="app-container">
        ${this.getTopBar()}
        ${this.getContextHeader()}
        ${this.getMainContent()}
        ${this.getProofFooter()}
      </div>
    `;
  }

  getTopBar() {
    const stepNum = this.getCurrentStepFromRoute();
    const isProof = stepNum === 'proof';
    
    return `
      <div class="top-bar">
        <div class="project-name">AI Resume Builder</div>
        <div class="progress-indicator">${isProof ? 'Proof Page' : `Project 3 — Step ${stepNum} of ${this.totalSteps}`}</div>
        <div class="status-badge ${this.status}">${this.formatStatus(this.status)}</div>
      </div>
    `;
  }

  getContextHeader() {
    const stepNum = this.getCurrentStepFromRoute();
    const isProof = stepNum === 'proof';
    
    if (isProof) {
      return `
        <div class="context-header">
          <h1>Project Completion Proof</h1>
          <p class="subtext">Review your progress and submit final project links</p>
        </div>
      `;
    }
    
    const stepTitles = {
      1: 'Problem Definition',
      2: 'Market Research',
      3: 'Architecture Design',
      4: 'High-Level Design',
      5: 'Low-Level Design',
      6: 'Build Implementation',
      7: 'Testing & Validation',
      8: 'Shipping & Deployment'
    };
    
    return `
      <div class="context-header">
        <h1>${stepTitles[stepNum]}</h1>
        <p class="subtext">Complete this step to unlock the next phase of your AI Resume Builder</p>
      </div>
    `;
  }

  getMainContent() {
    const stepNum = this.getCurrentStepFromRoute();
    const isProof = stepNum === 'proof';
    
    if (isProof) {
      return this.getProofContent();
    }
    
    return `
      <div class="main-content">
        <div class="primary-workspace">
          <div class="card">
            <h3>Step ${stepNum} - Artifact Upload</h3>
            <p>Upload your work for this step. Only proceed when you have completed the artifact.</p>
            
            <div class="mb-md">
              <h4>Artifact for Step ${stepNum}</h4>
              <div class="mb-sm">
                <textarea 
                  class="input textarea" 
                  id="artifact-input-${stepNum}"
                  placeholder="Paste your artifact content here (code, documentation, links, etc.)..."
                  ${this.stepCompleted[stepNum] ? 'disabled' : ''}
                >${this.artifacts[stepNum] || ''}</textarea>
              </div>
              
              <div class="btn-group mb-sm">
                <button 
                  class="btn btn-primary" 
                  onclick="aiResumeBuilder.uploadArtifact(${stepNum})"
                  ${this.stepCompleted[stepNum] ? 'disabled' : ''}
                >
                  ${this.stepCompleted[stepNum] ? '✓ Artifact Uploaded' : 'Upload Artifact'}
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div class="secondary-panel">
          <div class="card">
            <h3>Build Instructions</h3>
            <p class="text-secondary mb-sm">Copy this prompt into Lovable to build this step:</p>
            
            <div class="prompt-box">
${this.getStepPrompt(stepNum)}
            </div>
            
            <div class="btn-group">
              <button class="btn btn-secondary btn-full" onclick="aiResumeBuilder.copyPrompt()">Copy Prompt</button>
              <button class="btn btn-primary btn-full" onclick="aiResumeBuilder.buildInLovable()">Build in Lovable</button>
              <button class="btn btn-secondary btn-full" onclick="aiResumeBuilder.markSuccess()">It Worked</button>
              <button class="btn btn-secondary btn-full" onclick="aiResumeBuilder.markError()">Error</button>
              <button class="btn btn-secondary btn-full" onclick="aiResumeBuilder.addScreenshot()">Add Screenshot</button>
            </div>
            
            ${this.getNavigationButtons(stepNum)}
          </div>
        </div>
      </div>
    `;
  }

  getStepPrompt(step) {
    const prompts = {
      1: `// Step 1: Problem Definition
Define the core problem that your AI Resume Builder will solve.
Consider: User pain points, market gaps, specific use cases.
Create a clear problem statement with measurable objectives.`,
      
      2: `// Step 2: Market Research
Research existing resume builders and AI tools in the market.
Analyze competitors, identify unique value propositions.
Define target audience and market positioning.`,
      
      3: `// Step 3: Architecture Design
Design the overall system architecture for AI Resume Builder.
Consider: Tech stack, data flow, AI integration points.
Create high-level architectural diagrams and decisions.`,
      
      4: `// Step 4: High-Level Design (HLD)
Create detailed high-level design specifications.
Define modules, interfaces, data structures.
Document API contracts and system boundaries.`,
      
      5: `// Step 5: Low-Level Design (LLD)
Create detailed low-level design specifications.
Define algorithms, database schemas, class designs.
Document implementation details and patterns.`,
      
      6: `// Step 6: Build Implementation
Implement the AI Resume Builder based on designs.
Focus on core functionality, AI integration, user experience.
Write clean, maintainable code with proper documentation.`,
      
      7: `// Step 7: Testing & Validation
Create comprehensive test suite for the application.
Test: Unit tests, integration tests, AI model validation.
Ensure quality, performance, and user acceptance.`,
      
      8: `// Step 8: Shipping & Deployment
Prepare the application for production deployment.
Consider: CI/CD pipeline, monitoring, security.
Deploy to production and validate end-to-end functionality.`
    };
    
    return prompts[step] || '// Follow the step requirements carefully';
  }

  getNavigationButtons(step) {
    const canGoNext = this.stepCompleted[step] && this.canAccessStep(step + 1);
    const canGoPrev = step > 1;
    
    return `
      <div class="navigation-buttons mt-md">
        <div class="btn-group">
          <button 
            class="btn btn-secondary" 
            onclick="aiResumeBuilder.goToStep(${step - 1})"
            ${!canGoPrev ? 'disabled' : ''}
          >
            ← Previous
          </button>
          <button 
            class="btn btn-primary" 
            onclick="aiResumeBuilder.goToStep(${step + 1})"
            ${!canGoNext ? 'disabled' : ''}
          >
            Next →
          </button>
        </div>
      </div>
    `;
  }

  getProofContent() {
    const allStepsCompleted = Object.values(this.stepCompleted).filter(Boolean).length === this.totalSteps;
    
    return `
      <div class="main-content">
        <div class="primary-workspace">
          <div class="card">
            <h3>Project Completion Status</h3>
            <p>Review your progress across all 8 steps of the AI Resume Builder project.</p>
            
            <div class="step-status-grid">
              ${this.getStepStatusGrid()}
            </div>
            
            ${allStepsCompleted ? `
              <div class="submission-form mt-md">
                <h4>Final Submission</h4>
                <div class="mb-sm">
                  <label class="input-label">Lovable Project Link</label>
                  <input type="url" class="input" id="lovable-link" placeholder="https://lovable.ai/projects/...">
                </div>
                <div class="mb-sm">
                  <label class="input-label">GitHub Repository Link</label>
                  <input type="url" class="input" id="github-link" placeholder="https://github.com/username/resume-builder">
                </div>
                <div class="mb-sm">
                  <label class="input-label">Deployed Application Link</label>
                  <input type="url" class="input" id="deploy-link" placeholder="https://your-app-domain.com">
                </div>
                <button class="btn btn-primary btn-full" onclick="aiResumeBuilder.copyFinalSubmission()">
                  Copy Final Submission
                </button>
              </div>
            ` : `
              <div class="error-state mt-md">
                <h3>Project Not Complete</h3>
                <p>Please complete all 8 steps before accessing the proof submission.</p>
              </div>
            `}
          </div>
        </div>
        
        <div class="secondary-panel">
          <div class="card">
            <h3>Project Summary</h3>
            <p class="text-secondary mb-sm">AI Resume Builder — Build Track</p>
            
            <div class="prompt-box">
Total Steps: ${this.totalSteps}
Completed: ${Object.values(this.stepCompleted).filter(Boolean).length}
Status: ${allStepsCompleted ? 'Ready for Submission' : 'In Progress'}

Project: AI Resume Builder
Track: Build Track
Framework: KodNest Premium Build System
            </div>
            
            <div class="btn-group">
              <button class="btn btn-secondary btn-full" onclick="aiResumeBuilder.exportProgress()">Export Progress</button>
              <button class="btn btn-primary btn-full" onclick="aiResumeBuilder.resetProject()">Reset Project</button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  getStepStatusGrid() {
    const stepNames = [
      'Problem Definition', 'Market Research', 'Architecture Design',
      'High-Level Design', 'Low-Level Design', 'Build Implementation',
      'Testing & Validation', 'Shipping & Deployment'
    ];
    
    return stepNames.map((name, index) => {
      const stepNum = index + 1;
      const completed = this.stepCompleted[stepNum];
      const hasArtifact = !!this.artifacts[stepNum];
      
      return `
        <div class="step-status-item ${completed ? 'completed' : 'pending'}">
          <div class="step-number">${stepNum}</div>
          <div class="step-info">
            <div class="step-name">${name}</div>
            <div class="step-status">
              ${completed ? '✓ Completed' : '○ Pending'}
              ${hasArtifact ? ' (Has Artifact)' : ''}
            </div>
          </div>
        </div>
      `;
    }).join('');
  }

  getProofFooter() {
    const stepNum = this.getCurrentStepFromRoute();
    const isProof = stepNum === 'proof';
    
    if (isProof) {
      return '';
    }
    
    return `
      <div class="proof-footer">
        <div class="proof-checklist">
          <div class="proof-item">
            <input type="checkbox" id="artifact-uploaded" ${this.stepCompleted[stepNum] ? 'checked' : ''}>
            <label for="artifact-uploaded">Artifact Uploaded</label>
          </div>
          <div class="proof-item">
            <input type="checkbox" id="build-tested">
            <label for="build-tested">Build Tested</label>
          </div>
          <div class="proof-item">
            <input type="checkbox" id="quality-checked">
            <label for="quality-checked">Quality Checked</label>
          </div>
          <div class="proof-item">
            <input type="checkbox" id="step-complete" ${this.stepCompleted[stepNum] ? 'checked' : ''}>
            <label for="step-complete">Step Complete</label>
          </div>
        </div>
      </div>
    `;
  }

  formatStatus(status) {
    return status.split('-').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  }

  attachEventListeners() {
    // Proof checkboxes
    const checkboxes = document.querySelectorAll('.proof-item input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
      checkbox.addEventListener('change', (e) => {
        this.handleProofCheck(e.target);
      });
    });
  }

  handleProofCheck(checkbox) {
    const isChecked = checkbox.checked;
    const label = checkbox.nextElementSibling;
    
    if (isChecked) {
      console.log(`Proof item checked: ${label.textContent}`);
    } else {
      console.log(`Proof item unchecked: ${label.textContent}`);
    }
    
    this.updateProgress();
  }

  updateProgress() {
    const checkboxes = document.querySelectorAll('.proof-item input[type="checkbox"]');
    const checkedCount = Array.from(checkboxes).filter(cb => cb.checked).length;
    
    if (checkedCount === 0) {
      this.setStatus('not-started');
    } else if (checkedCount < checkboxes.length) {
      this.setStatus('in-progress');
    } else {
      this.setStatus('shipped');
    }
  }

  setStatus(newStatus) {
    this.status = newStatus;
    const statusBadge = document.querySelector('.status-badge');
    if (statusBadge) {
      statusBadge.className = `status-badge ${newStatus}`;
      statusBadge.textContent = this.formatStatus(newStatus);
    }
  }

  uploadArtifact(step) {
    const textarea = document.getElementById(`artifact-input-${step}`);
    if (textarea && textarea.value.trim()) {
      this.artifacts[step] = textarea.value.trim();
      this.stepCompleted[step] = true;
      this.showNotification(`Artifact for Step ${step} uploaded successfully!`);
      this.render();
    } else {
      this.showNotification('Please enter artifact content before uploading.');
    }
  }

  goToStep(step) {
    if (step < 1 || step > this.totalSteps) {
      if (step === 'proof') {
        window.location.hash = '#rb/proof';
        return;
      }
      return;
    }
    
    if (this.canAccessStep(step)) {
      window.location.hash = `#rb/0${step}-` + ['problem', 'market', 'architecture', 'hld', 'lld', 'build', 'test', 'ship'][step - 1];
    } else {
      this.showNotification('Complete previous steps first to unlock this step.');
    }
  }

  copyPrompt() {
    const promptBox = document.querySelector('.prompt-box');
    if (promptBox) {
      navigator.clipboard.writeText(promptBox.textContent.trim()).then(() => {
        this.showNotification('Prompt copied to clipboard');
      });
    }
  }

  buildInLovable() {
    this.showNotification('Opening Lovable integration...');
  }

  markSuccess() {
    this.showNotification('Marked as successful');
  }

  markError() {
    this.showNotification('Error reported');
  }

  addScreenshot() {
    this.showNotification('Screenshot upload dialog would open here');
  }

  copyFinalSubmission() {
    const lovableLink = document.getElementById('lovable-link')?.value || '';
    const githubLink = document.getElementById('github-link')?.value || '';
    const deployLink = document.getElementById('deploy-link')?.value || '';
    
    const submission = `AI Resume Builder - Build Track - Final Submission

Project Links:
- Lovable: ${lovableLink}
- GitHub: ${githubLink}
- Deployed: ${deployLink}

Steps Completed: ${Object.values(this.stepCompleted).filter(Boolean).length}/${this.totalSteps}

Artifacts:
${Object.entries(this.artifacts).map(([step, content]) => 
  `Step ${step}: ${content.substring(0, 100)}...`
).join('\n')}`;
    
    navigator.clipboard.writeText(submission).then(() => {
      this.showNotification('Final submission copied to clipboard');
    });
  }

  exportProgress() {
    const progress = {
      project: 'AI Resume Builder',
      track: 'Build Track',
      totalSteps: this.totalSteps,
      completedSteps: Object.values(this.stepCompleted).filter(Boolean).length,
      stepCompleted: this.stepCompleted,
      artifacts: this.artifacts,
      status: this.status
    };
    
    const blob = new Blob([JSON.stringify(progress, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ai-resume-builder-progress.json';
    a.click();
    URL.revokeObjectURL(url);
    
    this.showNotification('Progress exported successfully');
  }

  resetProject() {
    if (confirm('Are you sure you want to reset the entire project? This will delete all artifacts and progress.')) {
      this.artifacts = {};
      this.stepCompleted = {};
      this.status = 'not-started';
      this.currentStep = 1;
      window.location.hash = '#rb/01-problem';
      this.showNotification('Project reset successfully');
    }
  }

  showNotification(message) {
    const notification = document.createElement('div');
    notification.textContent = message;
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: var(--color-accent);
      color: white;
      padding: 12px 16px;
      border-radius: 4px;
      z-index: 1000;
      font-size: 14px;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      document.body.removeChild(notification);
    }, 3000);
  }

  updateStep(step) {
    this.currentStep = step;
    const progressIndicator = document.querySelector('.progress-indicator');
    if (progressIndicator) {
      progressIndicator.textContent = `Step ${this.currentStep} / ${this.totalSteps}`;
    }
  }
}

// Initialize the app when DOM is ready
let aiResumeBuilder;
document.addEventListener('DOMContentLoaded', () => {
  aiResumeBuilder = new AIResumeBuilder();
});

// Export for global access
window.aiResumeBuilder = aiResumeBuilder;
