# KodNest Premium Build System

A premium SaaS design system built with calm, intentional, and coherent design principles.

## Design Philosophy

- **Calm**: No visual noise, no overwhelming elements
- **Intentional**: Every component has a clear purpose
- **Coherent**: Consistent design language throughout
- **Confident**: Professional, understated aesthetic

## Color System

- **Background**: `#F7F6F3` (off-white)
- **Primary Text**: `#111111` (deep black)
- **Accent**: `#8B0000` (deep red)
- **Success**: `#6B7F6B` (muted green)
- **Warning**: `#B8955A` (muted amber)
- **Border**: `#E5E4E1` (subtle gray)

## Typography

- **Headings**: Georgia serif, generous spacing, confident sizing
- **Body**: System sans-serif, 16–18px, line-height 1.6–1.8
- **Max text width**: 720px for readability

## Spacing Scale

Consistent 8px-based scale:
- `--space-xs`: 8px
- `--space-sm`: 16px
- `--space-md`: 24px
- `--space-lg`: 40px
- `--space-xl`: 64px

## Layout Structure

Every page follows the global layout:
1. **Top Bar** → Project name, progress, status
2. **Context Header** → Large headline, subtext, purpose
3. **Main Content** → Primary workspace (70%) + Secondary panel (30%)
4. **Proof Footer** → Persistent checklist with user proof

## Components

### Buttons
- **Primary**: Solid deep red background
- **Secondary**: Outlined with border
- Consistent hover effects and 44px minimum height

### Form Elements
- Clean borders with subtle focus states
- No heavy shadows or decorative elements
- Consistent border radius and padding

### Cards
- Subtle borders, no drop shadows
- Balanced padding and spacing
- White background on off-white base

### Status Badges
- Three states: Not Started, In Progress, Shipped
- Clear visual hierarchy
- Uppercase with letter spacing

## Interaction Rules

- **Transitions**: 150–200ms ease-in-out
- **No bounce effects or parallax**
- **Consistent hover states**
- **Clear focus indicators**

## Error & Empty States

- **Errors**: Clear explanation + fix guidance
- **Empty states**: Next action provided
- **Never blame the user**

## Getting Started

1. Clone or download the design system
2. Open `index.html` in a browser
3. Use `npm run dev` for local development

## File Structure

```
kodnest-premium-build-system/
├── index.html              # Main demo page
├── package.json            # Project configuration
├── README.md              # This documentation
├── styles/
│   └── design-system.css  # Complete CSS design system
└── js/
    └── components.js      # JavaScript components and interactions
```

## Usage

The design system is self-contained. Simply link the CSS and include the JavaScript:

```html
<link rel="stylesheet" href="styles/design-system.css">
<script src="js/components.js"></script>
```

All components use CSS custom properties for easy customization:

```css
:root {
  --color-accent: #your-brand-color;
  --font-serif: 'Your-Font', serif;
}
```

## Browser Support

- Modern browsers (Chrome, Firefox, Safari, Edge)
- CSS custom properties support required
- Responsive design for mobile and desktop

## License

MIT License - feel free to use in commercial projects.
